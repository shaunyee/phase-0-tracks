def calculate #(x,operator,y)

 arry = []
 
  puts "Welcome to my Calculator"

  loop do 
   puts "Would you like to +, -, * or / ? or type done when finished"
    operator = gets.chomp
   break if operator == "done" 
   puts arry
   puts "What is the first number you would like to calculate?"
   x = gets.chomp.to_i
   puts "What is the second number you are calculating with?"
   y = gets.chomp.to_i
 
   if operator == "+"
    puts result= x + y
  elsif operator == "-"
    puts result = x - y
  elsif operator == "*"
    puts result = x * y
  elsif operator == "/"
    puts result = x / y 
    

end
  end
end

#calculate(4,"+",5)
#calculate(5,"-",4)
#calculate(5,"*",4)
#calculate(10,"/",2)